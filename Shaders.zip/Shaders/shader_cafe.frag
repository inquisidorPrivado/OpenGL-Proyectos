#version 330
out vec4 color;
void main() {
    color = vec4(0.54, 0.27, 0.07, 1.0);
}